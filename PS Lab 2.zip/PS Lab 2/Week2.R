for (i in 1:10){
  print(i)
}

data1 <- read.csv("C:/Users/sa22521620/Desktop/PS/heightweight.csv")
data2 <- read.csv("heightweight.csv")
data1 <- read.table(heightweight, header=TRUE, sep=",")

data1

write.csv(data1, file = "test.csv")
fix(data1)

MKST <- data.frame(Names =c(), ST402 =c(), ST419 =c(), ST422 =c())
fix(MKST)
MKST

# Or we can Use.
Name <- c("Ali","Beth")
ST402 <- c(52,40)
ST419 <- c(69,82)
ST422 <- c(71,84)
MKST <- data.frame(Name, ST402, ST419, ST422)


#get info for hist commands
?hist

#Creating a histogram with X being ST402
hist(MKST$ST402)
hist(MKST$ST402, probability =TRUE)
hist(MKST$ST402, nclass =10)
hist(MKST$ST402, breaks = c(0,20,25,30,40,50,60,70,80,90,100))

#boxplot
boxplot(MKST$ST402,MKST$ST419,MKST$ST422)
boxplot(MKST, main="Exam Scores", ylab="Scores", horizontal =  TRUE)
boxplot( MKST2, main="Exam Scores", ylab="Scores")
MKST2 = subset(MKST, select = -c(Name))
#scatter
plot(MKST$ST402,MKST$ST419)
plot(MKST$ST402,MKST$ST419, type ="p")
plot(MKST$ST402,MKST$ST419, pch ="🐱",col="blue")

?plot

#exercise
#question 3
even_function <- function(){
count = readline()
count = as.integer(count)
i =0
sum = 0
while (i <= count) {
  if(i %% 2 == 0)
  {
    sum = sum + i
  }
  i = i + 1
}
sum
}

squaredsum_function <- function(){
  max = 10
  i =0
  sum = 0
  while (i <= max) {
    sum = sum + i^2
    i = i + 1
  }
  sum
}

even_function()
squaredsum_function()

#or we can use sequence.
evensum <- function(n){sum(seq(0,2*n,2))}
evensum(2)